These HTML files are submitted as an Assignment which includes Basic of HTML.
